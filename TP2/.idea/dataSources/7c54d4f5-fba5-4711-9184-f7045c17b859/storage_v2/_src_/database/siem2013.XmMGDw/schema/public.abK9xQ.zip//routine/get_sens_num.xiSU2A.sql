create function get_sens_num()
    returns TABLE(room_id integer, sensor_count integer)
    language plpgsql
as
$$
DECLARE
 _counter INTEGER;
BEGIN
 SET search_path TO 'db-relational';
 CREATE TEMP TABLE res (room_id INTEGER, sensor_count INTEGER);
 FOR _counter IN SELECT id FROM room LOOP
  INSERT INTO res VALUES (_counter, (SELECT COUNT(*) FROM sensors WHERE room_id = _counter) );
 END LOOP;
 RETURN QUERY SELECT * FROM res;
END;
$$;

alter function get_sens_num() owner to sinf19a43;

