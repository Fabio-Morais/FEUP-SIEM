create function sensor_changes() returns trigger
    language plpgsql
as
$$
BEGIN
 IF NEW.divisao <> OLD.divisao THEN
  INSERT INTO test(sensor,antiga,nova) VALUES (OLD.nome, OLD.divisao, NEW.divisao);
 END IF;
 RETURN NEW;
END;
$$;

alter function sensor_changes() owner to sinfa33;

