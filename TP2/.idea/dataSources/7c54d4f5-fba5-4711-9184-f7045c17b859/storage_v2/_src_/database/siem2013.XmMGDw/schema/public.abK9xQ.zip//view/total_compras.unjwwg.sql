create view total_compras(id_equipa, id_material, quantidade) as
SELECT compra.id_equipa,
       compra.id_material,
       sum(compra.quantidade) AS quantidade
FROM compra,
     material
WHERE material.id_material = compra.id_material
GROUP BY compra.id_equipa, compra.id_material, material.nome_material;

alter table total_compras
    owner to ee10067;

