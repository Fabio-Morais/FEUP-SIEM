﻿<?php session_start(); ?>

<!DOCTYPE html>
<html lang="pt">

<head>
  <title>ExplicaFeup</title>
  <link rel="shortcut icon" type="image/x-icon" href="img/icon.png" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/pageLayout.css">
  <link rel="stylesheet" href="css/responsiveStyle.css">
  <!-- Add icon library -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- font awesome -->
  <script src="https://kit.fontawesome.com/70d6b09e06.js" crossorigin="anonymous"></script>
    <!--JQUERY-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <!--Google font-->
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Roboto|Roboto:700|Open+Sans:600|Open+Sans:700|Noto+Sans+JP:700|Bree+Serif">
  <!--Animations-->
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

</head>

<body>
  <header>
      <div class="topnav">
          <a class="logo" href="index.php">
              <img src="img/icon.png">
              <h5 id="explic">ExplicaFeup</h5>
          </a>
          <!--Versão mobile-->
          <div class="dropdown">
              <button class="dropbtn"><i class="fas fa-bars"></i></button>
              <div class="dropdown-content">
                  <a href="about.php">Quem Somos</a>
                  <a href="schedule.php">Horário</a>
                  <a href="courses.php">Cursos</a>
                  <a href="contacts.php">Contactos</a>
                  <?php 
                  if(isset($_SESSION['login']) && $_SESSION['login'] == TRUE){
                    echo "<a id=\"elemnt\" href=\"dashboard/index.php\">Dashboard</a>";
                  } else{
                    echo "<a id=\"elemnt\" href=\"dashboard/login.php\">Dashboard</a>";
                  }
                  ?>
              </div>
          </div>
          <!--Versão desktop-->
          <?php 
          if(isset($_SESSION['login']) && $_SESSION['login'] == TRUE){
            echo "<a id=\"elemnt\" href=\"dashboard/index.php\">Dashboard</a>";
          } else{
            echo "<a id=\"elemnt\" href=\"dashboard/login.php\">Dashboard</a>";
          }
          ?>
          <a id="elemnt" href="contacts.php">Contactos</a>
          <a id="elemnt" href="courses.php">Cursos</a>
          <a id="elemnt" href="schedule.php">Horário</a>
          <a id="elemnt" href="about.php">Quem Somos</a>
      </div>
  </header>

  <!-- HEAD principal -->
  <div class="head" id="home">
    <!--Titulos e botoes-->
    <div id="sloganContainer">
      <h2 data-aos="fade-up">Nº1 em cursos de tech</h2>
      <div class="line1" data-aos="fade-up"></div>
      <h3 data-aos="fade-up">Aprende ao teu ritmo</h3>
      <div class="container2">
        <div data-aos="fade-right" data-aos-delay="400" data-aos-once="true"><button class="button butText" id="button1"
            onclick="window.location.href='about.php';">Sobre nós</button></div>
        <div data-aos="fade-right" data-aos-delay="400" data-aos-once="true"><button class="button butText" id="button2"
            onclick="window.location.href='courses.php';"><span class="butText">Cursos</span></button></div>
      </div>
    </div>
    <!--Animaçao da seta para baixo-->
    <div class="flex-column" id="arrowContainer">
      <div class="arrow bounce">
        <a class="fa fa-arrow-down fa-2x" href="#secSponsor"></a>
      </div>
    </div>
  </div>
  <!--MODAL INICIAL-->
  <div id="id1" class="modal">
    <div class="modal-content animate" id="initialContent">
      <div class="imgcontainer">
        <span onclick="document.getElementById('id1').style.display='none'" class="close"
          title="Close Modal">&times;</span>
      </div>
      <div class="container" id="initModalCont">
        <h2>Bem vindo ao ExplicaFeup</h2>
        <div class="line3"></div>
        <div class="flex-wrap flex-around">
          <!--Imagem-->
          <div class="flex-column" id="photoName">
            <div id="photoBorder"><img src="img/fabio.jpeg" id="photoInit"></div>
            <h4>Fábio Morais</h4>
          </div>
          <div class="flex-column" id="downloadButtons">
            <!--Texto-->
            <p id="initialText">Trabalho realizado no âmbito da unidade curricular Sistemas de Informação Empresariais,
              pertencente ao plano de estudos do MIEEC da FEUP.</p>
            <p id="initialText"><b>Email: </b>up201504257@fe.up.pt</p>
            <p id="initialText"><b>Browser preferencial: </b> Chrome</p>
            <p id="initialText">Website otimizado e testado para resoluções até 1920 x 1080. <b>Testado para mobile</b>
            </p>
            <!--Botoes para download-->
            <div class="flex-wrap flex-center">
              <div id="downloadButton"><a href="documentation.zip" download><button class="button buttonRed"
                    href="add-website-here" target="_blank">
                    <div class="flex-column"><i class="far fa-file-powerpoint"></i> Download ppt</div>
                  </button></a></div>
              <div id="downloadButton"><a href="website.zip" download><button class="button buttonRed"
                    href="add-website-here" target="_blank">
                    <div class="flex-column"><i class="far fa-file-code"></i> Download Website</div>
                  </button></a></div>
              <div id="downloadButton"><a href="css.zip" download><button class="button buttonRed"
                    href="add-website-here" target="_blank">
                    <div class="flex-column"><i class="fab fa-css3-alt"></i> Download CSS</div>
                  </button></a></div>
            </div>
          </div>
        </div>
      </div>
      <!--Botao para fechar o pop up-->
      <div class="container" id="modalBtnContainer">
        <button type="button" onclick="document.getElementById('id1').style.display='none'"
          class="cancelbtn button">Avançar</button>
      </div>
    </div>
  </div>

  <!-- SPONSORS -->
  <div class="section" id="secSponsor">
    <div class="container ">
      <div class="flex-wrap flex-around" id="sponsors">
        <div id="sponsor" data-aos="fade-right" data-aos-delay="100" data-aos-once="true"><img
            src="img/sponsors/feup.png"></div>
        <div id="sponsor" data-aos="fade-right" data-aos-delay="200" data-aos-once="true"><img
            src="img/sponsors/inesc.png"></div>
        <div id="sponsor" data-aos="fade-right" data-aos-delay="300" data-aos-once="true"><img
            src="img/sponsors/face.png"></div>
        <div id="sponsor" data-aos="fade-right" data-aos-delay="400" data-aos-once="true"><img
            src="img/sponsors/mit.png"></div>
      </div>
    </div>
  </div>

  <!-- SERVICES -->
  <div class="section" id="secServices">
    <div class="container">
      <h2>Serviços
        <div class="line2"></div>
      </h2>
      <div class="flex flex-around" id="services">
        <!--Box de texto-->
        <div class="flex-column" id="service" data-aos="fade-up" data-aos-delay="100" data-aos-once="true">
          <div><img src="img/services/certificate2.png"></div>
          <h5>Certificado</h5>
          <p>Todos os cursos inclui um certificado</p>
        </div>
        <!--Box de texto-->
        <div class="flex-column" id="service" data-aos="fade-up" data-aos-delay="300" data-aos-once="true">
          <div><img src="img/services/classes2.png"></div>
          <h5>Online ou presencial</h5>
          <p>Podes escolher entre ter aulas online ou presenciais</p>
        </div>
        <!--Box de texto-->
        <div class="flex-column" id="service" data-aos="fade-up" data-aos-delay="500" data-aos-once="true">
          <div><img src="img/services/job2.png"></div>
          <h5>Emprego garantido</h5>
          <p>No final dos cursos tens oportunidades de integrar numa empresa parceira</p>
        </div>
      </div>
    </div>
  </div>

  <!-- NUMBERS -->
  <div class="section" id="secNumbers">
    <div class="container">
      <h2>Números
        <div class="line2"></div>
      </h2>
      <div class="flex-nowrap flex-around" id="numbers">
        <!--Box com icon, numeros e texto-->
        <div class="flex-column" id="numberContainer">
          <div id="numberIcon" class="flex-nowrap">
            <i class="fas fa-laptop"></i>
            <h5 id="countCourse">10</h5>
          </div>
          <p>
            Cursos
          </p>
        </div>
        <!--Box com icon, numeros e texto-->
        <div class="flex-column" id="numberContainer">
          <div id="numberIcon" class="flex-nowrap">
            <i class="far fa-heart"></i>
            <h5 id="countClients">200</h5>
          </div>
          <p>
            Clientes Felizes
          </p>
        </div>
        <!--Box com icon, numeros e texto-->
        <div class="flex-column" id="numberContainer">
          <div id="numberIcon" class="flex-nowrap">
            <i class="far fa-clock"></i>
            <h5 id="countYears">10</h5>
          </div>
          <p>
            Anos de Experiência
          </p>
        </div>
      </div>
    </div>
  </div>

  <!-- TESTIMONIALS -->
  <div class="section" id="secTestimonials">
    <div class="container">
      <h2>Testemunhos
        <div class="line2"></div>
      </h2>
      <div class="flex-wrap flex-center" id="testimonials" data-aos="flip-up" data-aos-delay="100" data-aos-once="true"
        data-aos-duration="1000">
        <!--Imagem e nome-->
        <div class="flex-column" id="imgTestimon">
          <img src="img/alberto.jpg">
          <h5>Alberto Santos</h5>
        </div>
        <!--Secçao do texto e estrelas-->
        <div id="textTestimon">
          <div id="quot"><img src="img/quot.png" width="38" height="38"></div>
          <p> A total disrupção do paradigma da programação. Um curso em que todos deveriam apostar.</p>
          <div id="quot2"><img src="img/quot2.png" width="38" height="38">
          </div>
          <!--Rating-->
          <div class="flex-center" id="ratingTestimon">
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
            <span class="fa fa-star checked"></span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- FOOTER -->
  <div class="footer">
    <h2>Contactos</h2>
    <div class="flex-nowrap flex-around" id="footerContainer">
      <!--Footer da ESQUERDA-->
      <div class="flex-column" id="informatContainer">
        <h3 class="footerTitle">ExplicaFeup</h3>
        <p><b><i class="fas fa-map-marker-alt"></i> Morada: </b><a href="https://goo.gl/maps/HA1QhKSYkD59LjxJA"
            target="_blank" id="email"> R. Dr. Roberto Frias, <br>4200-465 Porto</a></p>
        <p><b><i class="fas fa-phone"></i> Telemóvel: </b>(+351) 926789452</p>
        <p><b><i class="fas fa-envelope-open-text"></i> Email: </b><a href="mailto:explicaFeup@example.com"
            id="email">explicaFeup@example.com </a></p>
      </div>
      <!--Footer do MEIO-->
      <div class="flex-column" id="informatContainer">
        <h3 class="footerTitle" >Horário</h3>
        <p>Segundas a sextas:</p>
        <p id="hours"><b><i class="fas fa-caret-right"></i> 10:00 - 18:00</b></p>
        <p>Sábados:</p>
        <p id="hours"><b><i class="fas fa-caret-right"></i> 10:00 - 13:00</b></p>
      </div>
      <!--Footer da direita-->
      <div class="flex-column" id="informatContainer">
        <h3 class="footerTitle">Redes Sociais</h3>
        <div class="socialMedia">
          <a href="https://www.facebook.com/" id="social" target="_blank" class="fa fa-facebook"></a>
          <a href="https://www.instagram.com" id="social" target="_blank" class="fa fa-instagram"></a>
          <a href="https://www.linkedin.com" id="social" target="_blank" class="fa fa-linkedin"></a>
        </div>
      </div>
    </div>
    <!--Botao para o pop up-->
    <p id="btnPopUp"><a onclick="document.getElementById('id1').style.display='block'" class="button">
        Abrir pop-up</a></p>
    <!--copyright-->
    <p>Copyright &copy; <a id="author" href="http://fabio-morais.github.io/" target="_blank"><b>Fábio Morais</b></a>
      SIEM 2020
    </p>
  </div>
  <script src="js/main.js"></script>
</body>

</html>